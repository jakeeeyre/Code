Colours
Darker blue - hex code #006b8c
Lighter blue - hex code #d2e4ed